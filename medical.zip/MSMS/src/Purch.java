
public class Purch {
    private int p_Id;
    private String c_name;
    private String SalesMan;
    private String m_name;
    private int m_Id;
    private int unit_price;
    private int m_quan;
    private String mfg_date;
     private String exp_date;
     private int total;
     public Purch(int p_Id,String c_name,String SalesMan,String m_name,int m_Id,int unit_price,int m_quan,String mfg_date,String exp_date,int total)
     {
         this.p_Id=p_Id;
         this.c_name=c_name;
         this.SalesMan=SalesMan;
         this.m_name=m_name;
         this.m_Id=m_Id;
         this.unit_price=unit_price;
         this.m_quan=m_quan;
         this.mfg_date=mfg_date;
         this.exp_date=exp_date;
         this.total=total;
         
         
     }
     public int getp_Id()
     {
         return p_Id;
     }
     public String getc_name()
     {
         return c_name;
     }
      public String getSalesMan()
     {
         return SalesMan;
     }
       public String getm_name()
     {
         return m_name;
     }
       public int getm_Id()
     {
         return m_Id;
     }
       public int getunit_price()
     {
         return unit_price;
     }
       public int getm_quan()
     {
         return m_quan;
     }
    public String getmfg_date()
     {
         return mfg_date;
     }
    public String getexp_date()
     {
         return exp_date;
     }
     public int gettotal()
     {
         return total;
     }
    
     
    
    
    
}
