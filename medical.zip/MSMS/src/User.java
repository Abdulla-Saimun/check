class User {
    private String name;
    private int id;
    private int rate;
    private int quantity;
    private int total;
    
    public User(int id,String name,int rate,int quantity,int total)
    {
        this.name=name;
        this.id=id;
        this.rate=rate;
        this.quantity=quantity;
        this.total=total;
    }
    
    public int getid()
    {
        return id;
    }
    public String getname()
    {
        return name;
    }
    public int getrate()
    {
        return rate;
    }
    public int getquantity()
    {
        return quantity;
    } 
    public int gettotal()
    {
        return total;
    }
}
