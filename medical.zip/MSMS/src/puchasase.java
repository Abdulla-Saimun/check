/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author abdul
 */
public class puchasase {
    int medquan;
    int unitprice;
    puchasase(int medquan,int unitprice)
    {
        this.medquan=medquan;
        this.unitprice= unitprice;
    }
    int calTotal()
    {
        return medquan*unitprice;
    }
    
    
}
